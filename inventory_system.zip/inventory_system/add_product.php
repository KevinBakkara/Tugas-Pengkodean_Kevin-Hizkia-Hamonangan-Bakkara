<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Produk</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Tambah Produk</h1>
    <form action="save_product.php" method="POST">
        <label for="name">Nama Produk:</label>
        <input type="text" id="name" name="name" required><br>

        <label for="price">Harga:</label>
        <input type="number" id="price" name="price" required><br>

        <label for="quantity">Stok:</label>
        <input type="number" id="quantity" name="quantity" required><br>

        <button type="submit">Simpan</button>
    </form>
    <a href="index.php">Kembali</a>
</body>
</html>