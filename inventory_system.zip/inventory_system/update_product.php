<?php
include 'db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$price = $_POST['price'];
$quantity = $_POST['quantity'];

// Update tabel Product
$sql = "UPDATE Product SET name='$name', price=$price WHERE id=$id";
if ($conn->query($sql) === TRUE) {
    // Update tabel Stock
    $sql_stock = "UPDATE Stock SET quantity=$quantity WHERE product_id=$id";
    if ($conn->query($sql_stock) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error: " . $sql_stock . "<br>" . $conn->error;
    }
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>