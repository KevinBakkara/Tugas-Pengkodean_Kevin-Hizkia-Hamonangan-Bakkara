<?php
include 'db.php';

$id = $_GET['id'];

// Hapus dari tabel Stock
$sql_stock = "DELETE FROM Stock WHERE product_id=$id";
if ($conn->query($sql_stock) === TRUE) {
    // Hapus dari tabel Product
    $sql = "DELETE FROM Product WHERE id=$id";
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Error: " . $sql_stock . "<br>" . $conn->error;
}

$conn->close();
?>