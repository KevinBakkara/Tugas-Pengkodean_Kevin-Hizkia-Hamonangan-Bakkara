<?php
include 'db.php';

$name = $_POST['name'];
$price = $_POST['price'];
$quantity = $_POST['quantity'];

// Insert ke tabel Product
$sql = "INSERT INTO Product (name, price) VALUES ('$name', $price)";
if ($conn->query($sql) === TRUE) {
    $product_id = $conn->insert_id;

    // Insert ke tabel Stock
    $sql_stock = "INSERT INTO Stock (product_id, quantity) VALUES ($product_id, $quantity)";
    if ($conn->query($sql_stock) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error: " . $sql_stock . "<br>" . $conn->error;
    }
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>