<?php
include 'db.php';

$id = $_GET['id'];
$sql = "SELECT p.id, p.name, p.price, s.quantity 
        FROM Product p 
        LEFT JOIN Stock s ON p.id = s.product_id 
        WHERE p.id = $id";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Edit Produk</h1>
    <form action="update_product.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <label for="name">Nama Produk:</label>
        <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>" required><br>

        <label for="price">Harga:</label>
        <input type="number" id="price" name="price" value="<?php echo $row['price']; ?>" required><br>

        <label for="quantity">Stok:</label>
        <input type="number" id="quantity" name="quantity" value="<?php echo $row['quantity']; ?>" required><br>

        <button type="submit">Simpan Perubahan</button>
    </form>
    <a href="index.php">Kembali</a>
</body>
</html>